package com.example.mytruyentranh.designPattern;

public interface Entity {
    public String getChap();
}
