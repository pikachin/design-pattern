package com.example.mytruyentranh.designPattern;

public interface IValidation {
    boolean valid(String data);
    boolean valid(String data, String data2);
}
