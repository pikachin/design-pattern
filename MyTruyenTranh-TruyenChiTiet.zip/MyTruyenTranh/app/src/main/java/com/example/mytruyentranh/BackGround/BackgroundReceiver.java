package com.example.mytruyentranh.BackGround;

import android.view.View;

public class BackgroundReceiver {
    public void setBackgroundColor(View view, int color) {
        view.setBackgroundColor(color);
    }
}
