package com.example.mytruyentranh;

public interface IValidation {
    boolean valid(String data);
    boolean valid(String data, String data2);
}
