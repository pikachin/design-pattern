package com.example.mytruyentranh.BackGround;

public interface Command {
    void execute();
}
