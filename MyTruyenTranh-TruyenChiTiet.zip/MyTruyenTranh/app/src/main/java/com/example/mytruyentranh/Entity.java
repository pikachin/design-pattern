package com.example.mytruyentranh;

public interface Entity {
    public String getChap();
}
